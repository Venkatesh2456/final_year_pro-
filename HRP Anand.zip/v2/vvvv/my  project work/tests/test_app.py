import pytest

def test_hello_world():
    assert "hello" + " " + "world" == "hello world"