from flask import Flask, render_template, redirect, url_for, session, request, flash
import sqlite3
import hashlib
import base64

app = Flask(__name__)
app.secret_key = 'your_secret_key'

from flask import Flask
from models import db

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Configure SQLite DB
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
db.init_app(app)

# Create tables on first run
with app.app_context():
    db.create_all()

def create_database():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            mobile TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS houses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            house_name TEXT NOT NULL,
            location TEXT NOT NULL,
            price INTEGER NOT NULL,
            description TEXT NOT NULL,
            owner_name TEXT NOT NULL,
            owner_email TEXT NOT NULL,
            owner_phone TEXT NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS house_photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            house_id INTEGER NOT NULL,
            photo TEXT NOT NULL,
            FOREIGN KEY (house_id) REFERENCES houses (id)
        )
    ''')

    conn.commit()
    conn.close()
    

@app.route("/")
def home():
    # fetch data from DB
    cur = sqlite3.connect('users.db').cursor()
    cur.execute("SELECT * FROM houses")
    houses = cur.fetchall()
    return render_template("home.html", houses=houses)


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        email_or_mobile = request.form['email_or_mobile']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        if '@' in email_or_mobile:
            cursor.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email_or_mobile, password))
        else:
            cursor.execute("SELECT * FROM users WHERE mobile = ? AND password = ?", (email_or_mobile, password))
        user = cursor.fetchone()
        conn.close()
        if user:
            session['email'] = email_or_mobile
            return redirect(url_for('info'))
        else:
            error = 'Invalid email or mobile number and password'
    return render_template('login.html', error=error)

@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        mobile = request.form['mobile']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (name, email, mobile, password) VALUES (?, ?, ?, ?)",
                           (name, email, mobile, password))
            conn.commit()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError as e:
            if 'email' in str(e):
                error = 'Email already registered'
            elif 'mobile' in str(e):
                error = 'Mobile number already registered'
            else:
                error = 'Registration error'
        finally:
            conn.close()

    return render_template('register.html', error=error)


@app.route('/logout')
def logout():
    session.pop('email', None)
    return redirect(url_for('login'))

@app.route('/rentsearch', methods=['GET', 'POST'])
def rent():
    results = []
    search_performed = False
    if request.method == 'POST':
        search_performed = True
        location = request.form['location']
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, house_name, location, price, description, owner_name, owner_email, owner_phone FROM houses WHERE location = ?", (location,))
        houses = cursor.fetchall()

        for house in houses:
            house_id = house[0]
            cursor.execute("SELECT photo FROM house_photos WHERE house_id = ?", (house_id,))
            photos = [row[0] for row in cursor.fetchall()]
            results.append((*house[1:], photos))

        conn.close()

    return render_template('rentsearch.html', results=results, search_performed=search_performed)

@app.route('/info')
def info():
    if 'email' in session:
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM houses")
        houses = cursor.fetchall()
        conn.close()
        return render_template('info.html', houses=houses)
    return redirect(url_for('login'))


@app.route('/rentout', methods=['GET', 'POST'])
def rentout():
    if request.method == 'POST':
        house_name = request.form['house_name']
        location = request.form['location']
        price = request.form['price']
        description = request.form['description']
        owner_name = request.form['owner_name']
        owner_email = request.form['owner_email']
        owner_phone = request.form['owner_phone']

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO houses (house_name, location, price, description, owner_name, owner_email, owner_phone) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       (house_name, location, price, description, owner_name, owner_email, owner_phone))
        house_id = cursor.lastrowid

        photos = request.files.getlist('photos')
        for photo in photos:
            if photo:
                photo_data = photo.read()
                photo_base64 = base64.b64encode(photo_data).decode('utf-8')
                cursor.execute("INSERT INTO house_photos (house_id, photo) VALUES (?, ?)", (house_id, photo_base64))

        conn.commit()
        conn.close()
        flash('House listed successfully with photos!')
        return redirect(url_for('info'))
    return render_template('rentout.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/admin_login', methods=['POST'])
def admin_login():
    email = request.form['email']
    password = request.form['password']
    if email == 'harish@gmail.com' and password == 'harish@204':
        return redirect(url_for('admin_dashboard'))
    else:
        return redirect(url_for('admin'))

@app.route('/admin_dashboard')
def admin_dashboard():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM houses")
    houses = cursor.fetchall()
    conn.close()
    return render_template('admininfo.html', houses=houses)

@app.route('/delete_rentout/<int:house_id>', methods=['POST'])
def delete_rentout(house_id):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM houses WHERE id = ?", (house_id,))
    cursor.execute("DELETE FROM house_photos WHERE house_id = ?", (house_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_dashboard'))

if __name__ == '__main__':
    create_database()
    app.run(debug=True)
