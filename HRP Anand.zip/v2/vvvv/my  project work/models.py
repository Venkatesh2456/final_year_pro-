import sqlite3
import hashlib
import base64

DATABASE = 'users.db'

def get_db_connection():
    return sqlite3.connect(DATABASE)

class User:
    @staticmethod
    def create(name, email, mobile, password):
        hashed_pw = hashlib.sha256(password.encode()).hexdigest()
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (name, email, mobile, password) VALUES (?, ?, ?, ?)",
                           (name, email, mobile, hashed_pw))
            conn.commit()
            return True, None
        except sqlite3.IntegrityError as e:
            return False, str(e)
        finally:
            conn.close()

    @staticmethod
    def authenticate(email_or_mobile, password):
        hashed_pw = hashlib.sha256(password.encode()).hexdigest()
        conn = get_db_connection()
        cursor = conn.cursor()
        if '@' in email_or_mobile:
            cursor.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email_or_mobile, hashed_pw))
        else:
            cursor.execute("SELECT * FROM users WHERE mobile = ? AND password = ?", (email_or_mobile, hashed_pw))
        user = cursor.fetchone()
        conn.close()
        return user

class House:
    @staticmethod
    def create(house_name, location, price, description, owner_name, owner_email, owner_phone):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO houses (house_name, location, price, description, owner_name, owner_email, owner_phone)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (house_name, location, price, description, owner_name, owner_email, owner_phone)
        )
        house_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return house_id

    @staticmethod
    def get_by_location(location):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM houses WHERE location = ?", (location,))
        houses = cursor.fetchall()
        conn.close()
        return houses

    @staticmethod
    def get_all():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM houses")
        houses = cursor.fetchall()
        conn.close()
        return houses

    @staticmethod
    def delete(house_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM houses WHERE id = ?", (house_id,))
        cursor.execute("DELETE FROM house_photos WHERE house_id = ?", (house_id,))
        conn.commit()
        conn.close()

class HousePhoto:
    @staticmethod
    def add_photos(house_id, photos):
        conn = get_db_connection()
        cursor = conn.cursor()
        for photo in photos:
            if photo:
                photo_data = photo.read()
                photo_base64 = base64.b64encode(photo_data).decode('utf-8')
                cursor.execute("INSERT INTO house_photos (house_id, photo) VALUES (?, ?)", (house_id, photo_base64))
        conn.commit()
        conn.close()

    @staticmethod
    def get_by_house(house_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT photo FROM house_photos WHERE house_id = ?", (house_id,))
        photos = [row[0] for row in cursor.fetchall()]
        conn.close()
        return photos
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    mobile = db.Column(db.String(15), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)

class House(db.Model):
    __tablename__ = 'houses'
    id = db.Column(db.Integer, primary_key=True)
    house_name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=False)
    owner_name = db.Column(db.String(100), nullable=False)
    owner_email = db.Column(db.String(100), nullable=False)
    owner_phone = db.Column(db.String(15), nullable=False)
    photos = db.relationship('HousePhoto', backref='house', cascade="all, delete-orphan")

class HousePhoto(db.Model):
    __tablename__ = 'house_photos'
    id = db.Column(db.Integer, primary_key=True)
    house_id = db.Column(db.Integer, db.ForeignKey('houses.id'), nullable=False)
    photo = db.Column(db.Text, nullable=False)
